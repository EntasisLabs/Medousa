import pathlib,subprocess,json,hashlib
p=pathlib.Path('/tmp/medousa-independent-f44c405'); commands={
'packaging':['python3','scripts/ci/test-daemon-packaging.py'],
'dependency-guard':['python3','scripts/ci/check-daemon-dependencies.py','--offline'],
'evidence-verifier':['python3','docs/reviews/daemon-ownership-evidence/correction-2026-11-13/verify-evidence.py'],
'diff-check':['git','diff','--check','effb18c2836df4ce2e5e88cd46876c685b0bb318','f44c405c3e91bbe160ed148b34265beffff25a1b'],
'rustfmt':['rustfmt','--edition','2024','--check','src/runtime/platform.rs','src/runtime/event_delivery.rs'],
'bash-syntax':['bash','-n','scripts/ci/test-platform-lifetime.sh','scripts/release/build.sh','scripts/mobile-dev-daemon.sh'],
'workflow-yaml':['ruby','-e','require "yaml"; ARGV.each { |f| YAML.parse_file(f); puts "PASS: #{f}" }','.github/workflows/ci.yml','.github/workflows/release.yml'],
'host-provenance':['sh','-c','rustc -Vv; cargo -V; rustup show active-toolchain; uname -a; df -k .; git rev-parse HEAD HEAD^; cat .cargo/config.toml'],
'runtime-ownership':['bash','scripts/ci/check-runtime-context.sh']}
results={}
for name,cmd in commands.items():
 r=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(p/(name+'.log')).write_text(r.stdout);results[name]=dict(command=cmd,exit_code=r.returncode);print(name,r.returncode,flush=True)
(p/'static-receipts.json').write_text(json.dumps(results,indent=2))
