import pathlib,os,subprocess,json,hashlib,re
out=pathlib.Path('/tmp/medousa-independent-f44c405'); binary=pathlib.Path(re.search(r'Running unittests src/lib.rs \(([^)]+)\)',(out/'lifetime.log').read_text())[1]).resolve(); results=[]
selectors=['runtime::platform::lifetime_tests::late_actual_constructor_failure_closes_observations_after_handler_registration','runtime::platform::lifetime_tests::polled_actual_constructor_cancellation_closes_observations_after_handler_registration']
for stack in [None,'33554432']:
 for i,s in enumerate(selectors):
  env=dict(os.environ,MEDOUSA_TEST_HERMETIC='1');env.pop('RUST_MIN_STACK',None)
  if stack:env['RUST_MIN_STACK']=stack
  cmd=[str(binary),s,'--ignored','--exact','--test-threads=1'];r=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90);label=f'constructor-{i+2}-stack-{stack or "default"}';(out/(label+'.log')).write_text(r.stdout);results.append(dict(label=label,command=cmd,exit_code=r.returncode,stack=stack));print(label,r.returncode,flush=True)
filters=['runtime::event_delivery::','ownership_tests::','runtime::settings::','tool_contract_baseline::','agent_runtime::spine_byte_parity::','grapheme_host_catalog::tests::','grapheme_runtime::tests::','engine_recovery::tests::recovery_replays_uncommitted_journal_and_marks_committed','daemon::request_boundary::tests::']
for i,s in enumerate(filters):
 cmd=[str(binary),s,'--test-threads=1'];r=subprocess.run(cmd,env=dict(os.environ,MEDOUSA_TEST_HERMETIC='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=120);label=f'focused-{i+1}';(out/(label+'.log')).write_text(r.stdout);summary=re.findall('test result:.*',r.stdout);results.append(dict(label=label,command=cmd,exit_code=r.returncode,summary=summary));print(label,r.returncode,summary,flush=True)
(out/'current-test-receipts.json').write_text(json.dumps(dict(binary=str(binary),sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),results=results),indent=2))
