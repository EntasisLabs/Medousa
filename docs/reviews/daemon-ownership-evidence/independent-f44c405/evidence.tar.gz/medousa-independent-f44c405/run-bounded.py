import os,subprocess,time,sys,json,signal
root=os.getcwd(); out='/tmp/medousa-independent-f44c405'; env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_TERM_COLOR='never',MEDOUSA_TEST_HERMETIC='1')
cmd=sys.argv[2:]; label=sys.argv[1]; samples=[]
with open(out+'/'+label+'.log','w') as f:
 p=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,env=env,start_new_session=True)
 stopped=False
 while p.poll() is None:
  free=os.statvfs(root).f_bavail*os.statvfs(root).f_frsize; samples.append(free)
  if free<8*1024**3:
   os.killpg(p.pid,signal.SIGINT);stopped=True
   try:p.wait(timeout=20)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGTERM)
   break
  time.sleep(2)
 rc=p.wait()
json.dump(dict(command=cmd,exit_code=rc,min_free_bytes=min(samples) if samples else None,stopped_at_8GiB=stopped,head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),env={k:env[k] for k in ['CARGO_BUILD_JOBS','MEDOUSA_TEST_HERMETIC']}),open(out+'/'+label+'.json','w'),indent=2)
print(label,rc,'min_free_GiB',min(samples)/1024**3 if samples else None);sys.exit(rc)
